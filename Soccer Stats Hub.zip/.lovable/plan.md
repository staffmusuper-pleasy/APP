# Pre-Sync Infrastructure

Before running the first full sync, build the foundations the user listed. Grouped by what the user can see vs. backend.

## 1. Configurable Source Priority

- New table `source_priorities (source text PK, priority int, enabled bool, updated_at)`.
- Seed with the requested order: API-Football(1), Football-Data(2), TheSportsDB(3), worldfootballR(4), OpenFootball(5).
- `sync-orchestrator` reads the table instead of hard-coding the order; ties fall back to `league_sources.priority` per competition.
- Editable from the Data Audit page (small table with priority up/down buttons + enabled switch).
- `matches.source` already exists — keep populating it on every upsert.

## 2. Coverage by Competition view

New SQL view `competition_coverage`:
- competition (league), season, total_matches, future_fixtures, source_used (modal source on stored matches), last_sync (max league_sources.last_successful_sync).

Render as a sortable table on `/data-audit` under a "Coverage by competition" card.

## 3. Data Quality Dashboard

New SQL view `data_quality_summary` exposing:
- duplicates_detected (matches sharing league_id+match_date+home+away)
- unmatched_teams (teams not referenced by any match OR matches with NULL team)
- matches_missing_stats (scheduled + future, missing statistics_cache for either side)
- failed_imports (sync_jobs status=error in last 24h)
- last_success_per_source, coverage_pct_per_source.

Render on `/data-audit` in a "Data quality" card with the numbers and a per-source breakdown.

## 4. teams_master normalization

New table `teams_master (id, official_name, normalized_name, country, active, created_at, updated_at)` + `teams.master_id` FK column.
- Trigger on `teams` insert/update: look up `team_aliases` and existing `teams_master` by normalized name+country; link or create.
- Backfill: collapse current `teams` rows into `teams_master` using `normalize_team_name`.
- All sync functions resolve via this layer (helper SQL function `resolve_team_master(name, country)`).

## 5. Betting analytics view

Materialized view `match_analytics` keyed by match_id with booleans/ints:
- btts, over_0_5..over_4_5, first_half_goals, second_half_goals, match_result (H/D/A), home_clean_sheet, away_clean_sheet.
- Refreshed by `calculate-statistics` after each sync.

(Half-time/half goals only populated when provider supplies them — nullable.)

## 6. Statistics storage expansion

Add nullable columns to `matches`:
- ht_home_goals, ht_away_goals, home_yellow, away_yellow, home_red, away_red, home_possession, away_possession, home_shots, away_shots, raw_payload jsonb.
- Existing home_cards/away_cards keep meaning (total cards) for back-compat.

## 7. Odds placeholder schema

Tables (empty, no jobs writing to them yet):
- bookmakers (id, name, country, active)
- odds_history (id, match_id, bookmaker_id, market, selection, price, captured_at)
- opening_odds, closing_odds (match_id, bookmaker_id, market, selection, price, captured_at)
- RLS: public read, authenticated write, service_role all.

## 8. import_logs audit trail

Table `import_logs (id, source, competition, started_at, completed_at, matches_imported, matches_updated, errors_count, status, error_sample)`.
- Each sync function writes one row per run.
- Surfaced on `/data-audit` as a recent-runs table.

## 9. Indexes

```
matches(league_id), matches(season), matches(match_date),
matches(home_team_id), matches(away_team_id),
matches(league_id, match_date), matches(source)
```
(Some may already exist — guarded with IF NOT EXISTS.)

## 10. Dry-run validator

New edge function `sync-dry-run`:
- Iterates `league_sources` (respects cooldown).
- For each source, asks for the next-page fixture list **without writing**.
- Returns: competitions_detected, seasons_detected, matches_expected, teams_expected, potential_duplicates (matches matching existing league+date+teams).

New button on `/data-audit`: "Run dry-run validation" → shows report. A second button "Run full sync" stays disabled until a dry-run has completed in the last 30 minutes with `errors_count = 0`.

## Out of scope
- Activating odds collection (schema only).
- Backfilling historical possession/shots (providers don't expose retroactively).

## Order of execution
1. Migration: tables + columns + indexes + views + seed `source_priorities`.
2. Wire sync functions to `source_priorities` + `import_logs` + `teams_master` resolver.
3. Add `sync-dry-run` edge function.
4. Extend `/data-audit` UI with the four new cards and the validation/sync gate.
5. User clicks dry-run → reviews → clicks full sync.
